package com.app.queue;

public class Node {

}
