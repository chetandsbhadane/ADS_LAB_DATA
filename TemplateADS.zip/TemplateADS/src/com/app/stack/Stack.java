package com.app.stack;

import com.app.entity.Employee;

public interface Stack {

	void push(Employee emp);
	
	void printStack();

}
